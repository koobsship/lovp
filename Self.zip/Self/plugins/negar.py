from pyrogram import Filters , Message , Client , InputMediaPhoto
import time
from db import r

@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Nn]egar$") , group=1)
def cmd_tbk(app : Client,msg : Message):
    txt = "I"
    app.send_message(
        msg.chat.id,
        txt,
        )

    txh = "Love"
    app.send_message(
        msg.chat.id,
        txh,
        )
    
    txf = "You"
    app.send_message(
        msg.chat.id,
        txf,
        )

    txj = "I Love You!"
    app.send_message(
        msg.chat.id,
        txj,
        )

    txv = "https://acegif.com/wp-content/uploads/gif-i-love-you-3.gif"
    app.send_animation(
        msg.chat.id,
        txv,
        )

    txp = "Do You Love Me?"
    app.send_message(
        msg.chat.id,
        txp,
        )
