from pyrogram import Filters , Message , Client , InlineKeyboardMarkup , ReplyKeyboardMarkup , ReplyKeyboardRemove , ForceReply
import time
from db import r
import sys
import os

run = os.system


flower = [
    "🌹",
    "🌹🌹",
    "🌹🌹🌹",
    "🌹🌹🌹🌹",
    "🌹🌹🌹🌹🌹",
    "🌹🌹🌹🌹🌹🌹",
    "🌹🌹🌹🌹🌹🌹🌹",
    "🌹🌹🌹🌹🌹🌹🌹🌹",
    "🌹🌹🌹🌹🌹🌹🌹",
    "🌹🌹🌹🌹🌹🌹",
    "🌹🌹🌹🌹🌹",
    "🌹🌹🌹🌹",
    "🌹🌹🌹",
    "🌹🌹",
    "🌹",
]

loveu = [
    "⏐",
    "I⏐",
    "I",
    "I⏐",
    "I ⏐",
    "I L⏐",
    "I L",
    "I L⏐",
    "I Lo⏐",
    "I Lo",
    "I Lo⏐",
    "I Lov⏐",
    "I Lov",
    "I Lov⏐",
    "I Love⏐",
    "I Love",
    "I Love⏐",
    "I Love ⏐",
    "I Love Y⏐",
    "I Love Y",
    "I Love Y⏐",
    "I Love Yo⏐",
    "I Love Yo",
    "I Love Yo⏐",
    "I Love You⏐",
    "I Love You",
    "I Love You⏐",
    "I Love You!⏐",
    "I Love You!",
    "I Love You!⏐",
    "I Love You!",
]

s = [
    "¿",
    "¿?",
    "¿?¿?",
    "¿?¿?¿",
    "¿?¿?¿?",
    "¿?¿?¿?¿",
    "¿?¿?¿?¿?",
    "¿?¿?¿?¿?¿",
    "¿?¿?¿?¿?¿?",
    "?¿?¿?¿?¿?¿",
    "¿?¿?¿?¿?¿?",
    "?¿?¿?¿?¿?¿",
    "¿?¿?¿?¿?¿?",
    "?¿?¿?¿?¿?¿",
    "¿?¿?¿?¿?¿?",
    "?¿?¿?¿?¿?¿",
    "¿?¿?¿?¿?¿?",
    "?¿?¿?¿?¿?¿",
    "¿?¿?¿?¿?¿?",
    "?¿?¿?¿?¿?¿",
    "¿?¿?¿?¿?¿?",
    "?¿?¿?¿?¿?¿",
    "¿?¿?¿?¿?¿?",
    "?¿?¿?¿?¿?¿",
    "¿?¿?¿?¿?¿?",
    "?¿?¿?¿?¿?¿",
    "¿?¿?¿?¿?¿?",
    "?¿?¿?¿?¿?¿",
    "¿?¿?¿?¿?¿?",
    "?¿?¿?¿?¿?¿",
    "¿?¿?¿?¿?¿?",
    "?¿?¿?¿?¿?¿",
]

@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Ss]oal$") , group=4)
def cvb(app : Client,msg : Message):
    for i in s:
        app.edit_message_text(msg.chat.id,msg.message_id,i)
        if r.get("autodel") == "on":
            time.sleep(float(r.get("autodeltime")))
            app.delete_messages(msg.chat.id,msg.message_id)
            
@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Ff]lower$") , group=7)
def cvkl(app : Client,msg : Message):
    for i in flower:
        app.edit_message_text(msg.chat.id,msg.message_id,i)
        if r.get("autodel") == "on":
            time.sleep(float(r.get("autodeltime")))
            app.delete_messages(msg.chat.id,msg.message_id)
            
@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Ll]oveu$") , group=9)
def cgf(app : Client,msg : Message):
    for i in loveu:
        app.edit_message_text(msg.chat.id,msg.message_id,i)
        if r.get("autodel") == "on":
            time.sleep(float(r.get("autodeltime")))
            app.delete_messages(msg.chat.id,msg.message_id)
            
