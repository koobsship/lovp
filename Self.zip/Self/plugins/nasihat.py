from pyrogram import Filters , Message , Client
from db import r
import time

nasi = [
    """
**- - - - - - - - -**
> `Kirshodan`
> `Noob`
> `Jagh`
> `Koslis`
> `Bekiram`
**- - - - - - - - -**
    """
]

@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Nn]asihatha$") , group=54)
def nasihat(app : Client,msg : Message):
    for i in nasi:
        app.edit_message_text(msg.chat.id,msg.message_id,i)
        if r.get("autodel") == "on":
            time.sleep(float(r.get("autodeltime")))
            app.delete_messages(msg.chat.id,msg.message_id)



@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Bb]ekiram$") , group=1)
def cmd_nas(app : Client,msg : Message):
    txl = '**در جواب بکیرم نگوییم\nبکیرم که بکیرت\nقبول کنیم که کیر شده ایم!**'
    app.send_message(
    msg.chat.id,
    txl,
    )
