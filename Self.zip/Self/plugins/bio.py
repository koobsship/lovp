from pyrogram import Filters , Message , Client
from db import r
import time

def bio(client,message):

    if " " in message.text:

        args = message.text.split(" ")
        mode =  args[1]

        #r.set("UpdateBio","False")
        if mode == "timer":
            r.set("bioaction", "timer")
            bio = "timer"
            text = f"BioAction `{bio}` Set Shode!"
        else:
            bio = " ".join(args[1:])
            r.set("biotext", bio)
            text = f"Biotext Seted to `{bio}` !"
    else:
        if r.get("UpdateBio") == "True":
            r.set("UpdateBio","False")
            text = f"BioAction Off Shod!"

        else:
            r.set("UpdateBio","True")
            text = f"BioAction On Shod!"
            send =app.edit_message_text(text=text,
                chat_id=message.chat.id,
                message_id=message.message_id)
            return bioaction()

        
    send =app.edit_message_text(text=text,
                chat_id=message.chat.id,
                message_id=message.message_id)
        
    if r.get("autodel") == "on":
        time.sleep(float(r.get("autodeltime")))
        app.delete_messages(message.chat.id,[send.message_id])


def biotext():
    if r.get("bioaction") == "timer":
        h, m, s = jdatetime.datetime.now().strftime("%H:%M:%S").split(":")
        Y, M, D = jdatetime.datetime.now().strftime("%y/%m/%d").split("/")
        bio = r.get("biotext")
        bio = bio.format(h=h, m=m, s=s, Y=Y, M=M, D=D)
    else:
        return False

    return bio

def bioaction():
 
    if r.get=="False":
        return


    print(biotext())
    app.send(
        functions.account.UpdateProfile(
            about=biotext()
        )
    )   
    
    time.sleep(int(r.get("biotime")) if r.get("biotime") else 65)
    return bioaction()
