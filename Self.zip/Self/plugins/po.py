#app.send_photo("me", "photo.jpg", caption="Holidays!")
#app.send_photo("me", "photo.jpg", caption="Holidays!")
#https://uupload.ir/files/lrep_photo_2020-12-18_14-59-03.jpg
from pyrogram import Client , Message , Filters , InputMediaPhoto
from db import r
import time

Hacking = [
    "Hacking User Started",
    "Hacking.",
    "Hacking..",
    "Hacking...",
    "Hacking.",
    "Hacking..",
    "Hacking...",
    "Hacking.",
    "Hacking..",
    "Hacking...",
    "10% █",
    "20% ██",
    "30% ███",
    "40% ████",
    "50% █████",
    "60% ██████",
    "70% ███████",
    "80% ████████",
    "90% █████████",
    "100% ██████████",
]


@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Hh]ack$") , group=1)
def help(app : Client ,msg : Message):
    txv = "__Ok Sir!__"
    app.send_message(
        msg.chat.id,
        txv,
        )
    txp = "**Pls Wait...**"
    app.send_message(
        msg.chat.id,
        txp,
        )
    txt = "https://uupload.ir/files/ige1_hacking-cybersecurity.gif"
    app.send_animation(
        msg.chat.id,
        txt,
        )
    time.sleep(4)
    txl = "**User Hacked!**"
    app.send_message(
        msg.chat.id,
        txl,
        )
    txl = "__User Info:\nName > Jende\nBoobs-Size > 85\nCountry > Iran\nSex > Mail__"
    app.send_message(
        msg.chat.id,
        txl,
        )

