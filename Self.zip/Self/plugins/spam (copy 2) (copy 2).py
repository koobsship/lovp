#app.send_photo("me", "photo.jpg", caption="Holidays!")
#app.send_photo("me", "photo.jpg", caption="Holidays!")
#https://uupload.ir/files/lrep_photo_2020-12-18_14-59-03.jpg
from pyrogram import Client , Message , Filters , InputMediaPhoto
from db import r
import time

@Client.on_message(Filters.regex("^[Gg]pinfo$") & Filters.me, group=32)
def help(app : Client ,msg : Message):
    txt = "https://uupload.ir/files/thk6_photo_2020-12-15_17-35-35.jpg"
    app.send_photo(
        msg.chat.id,
        txt,
        )
    txf = "__~ Group Info:\nGroup-Name > IranianZeroDay Security Group\nGroup-Bio >\n~ IranianZeroDay-Group\n> Welcome To Our Group Baby\n> Spam = Mute\n> Ask Your Question In One Message Not Spam!\n> Group Link :\nhttps://t.me/joinchat/VnpOZkgvZi3pheFlQ-bkKQ\nGroup-ID > 1211065901\nOnline-Members > 6 OF 177__"
    app.send_message(
        msg.chat.id,
        txf,
        )
#@Client.on_message(Filters.regex("^[Hh]eartless$") & Filters.me, group=32)
#@Client.on_message(Filters.regex("^[Hh]eartless$") & Filters.me, group=32)
#def h(app : Client ,msg : Message):
