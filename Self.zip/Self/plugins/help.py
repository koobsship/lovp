from pyrogram import Client , Message , Filters , Emoji
from db import r
import time

@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[hH]elp$") & Filters.me, group=30)
def help(app : Client ,msg : Message):
    txt = "__Send Helpc To Show Commands OF Self\n\nSend Helpt To show Tools OF Self__"
    app.send_message(
            msg.chat.id,
            txt,
            )

    if r.get("autodel") == "on":
            time.sleep(float(r.get("autodeltime")))
            app.delete_messages(msg.chat.id,msg.message_id)
            
            

TARGET = "kali_liinux"  # Target chat. Can also be a list of multiple chat ids/usernames
MENTION = "[{}](tg://user?id={})"  # User mention markup
MESSAGE = "{} Welcome to group chat {}!"  # Welcome message


# Filter in only new_chat_members updates generated in TARGET chat
@Client.on_message(Filters.chat(TARGET) & Filters.new_chat_members & Filters.group)
def welcome(app : Client ,msg : Message):
    # Build the new members list (with mentions) by using their first_name
    new_members = [u.mention for u in message.new_chat_members]

    # Build the welcome message by using an emoji and the list we built above
    text = MESSAGE.format(emoji.SPARKLES, ", ".join(new_members))

    # Send the welcome message, without the web page preview
    msg.reply_text(text, disable_web_page_preview=True)

    app.send_message(
        msg.chat.id,
        text,
        )
