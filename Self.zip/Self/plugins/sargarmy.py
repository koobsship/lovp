from pyrogram import Filters , Message , Client , InlineKeyboardMarkup , ReplyKeyboardMarkup , ReplyKeyboardRemove , ForceReply
import time
from db import r


game = [

    ".",
    "@gamee MotoFX 2",
]

cat = [
    "😺😹😺😹😺😹😺😹",
    "😹😺😹😺😹😺😹😺",
    "😺😹😺😹😺😹😺😹",
    "😹😺😹😺😹😺😹😺",
    "😺😹😺😹😺😹😺😹",
    "😹😺😹😺😹😺😹😺",
    "😺😹😺😹😺😹😺😹",
    "😹😺😹😺😹😺😹😺",
    "😺😹😺😹😺😹😺😹",
    "😹😺😹😺😹😺😹😺",
    "😺😹😺😹😺😹😺😹",
    "😹😺😹😺😹😺😹😺",
    "😺😹😺😹😺😹😺😹",
    "😹😺😹😺😹😺😹😺",
    "😺😹😺😹😺😹😺😹",
    "😹😺😹😺😹😺😹😺",
    "😺😹😺😹😺😹😺😹",
    "😹😺😹😺😹😺😹😺",
    "😺😹😺😹😺😹😺😹",
    "😹😺😹😺😹😺😹😺",
    "😺😹😺😹😺😹😺😹",
    "😹😺😹😺😹😺😹😺",
    "😺😹😺😹😺😹😺😹",
    "😹😺😹😺😹😺😹😺",
    "😺😹😺😹😺😹😺😹",
    "😹😺😹😺😹😺😹😺",
    "😺😹😺😹😺😹😺😹",
    "😹😺😹😺😹😺😹😺",
    "😺😹😺😹😺😹😺😹",
    "😹😺😹😺😹😺😹😺",
    "😺😹😺😹😺😹😺😹",
    "😹😺😹😺😹😺😹😺",
    "😺😹😺😹😺😹😺😹",
    "😹😺😹😺😹😺😹😺",
    "😺😹😺😹😺😹😺😹",
    "😹😺😹😺😹😺😹😺",
    "😺😹😺😹😺😹😺😹",
    "😹😺😹😺😹😺😹😺",
    "😺😹😺😹😺😹😺😹",
    "😹😺😹😺😹😺😹😺",
]

oof = [
    "ooof",
    "oooof",
    "ooooof",
    "oooooof",
    "ooooooof",
    "oooooooof",
    "ooooooooof",
    "oooooooooof",
    "ooooooooooof",
    "oooooooooooof",
    "ooooooooooooof",
]


@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Cc]at$") , group=4)
def cmd(app : Client,msg : Message):
    for i in cat:
        app.edit_message_text(msg.chat.id,msg.message_id,i)
        if r.get("autodel") == "on":
            time.sleep(float(r.get("autodeltime")))
            app.delete_messages(msg.chat.id,msg.message_id)
            

@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Oo]of$") , group=1)
def cmd_reload(app : Client,msg : Message):
    for i in oof:
        app.edit_message_text(msg.chat.id,msg.message_id,i)
        if r.get("autodel") == "on":
            time.sleep(float(r.get("autodeltime")))
            app.delete_messages(msg.chat.id,msg.message_id)

@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Kk]irshodan$") , group=1)
def kirsh(app : Client,msg : Message):
    txt = '**کیر شدن جرم نیست!\nهرگز از ان نهراسید**💋' 
    app.send_message(
    msg.chat.id,
    txt,
    )

@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Nn]oob$") , group=1)
def noob(app : Client,msg : Message):
    txo = '**نوبای دیروز شاخای امروز:/**'
    app.send_message(
    msg.chat.id,
    txo,
    )

@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Jj]agh$") , group=1)
def jagh(app : Client,msg : Message):
    txf = '**در جوانی منت کص را مکش\nدست خود را حلقه کن بر قامت کیرت بکش!**'
    app.send_message(
    msg.chat.id,
    txf,
    )

@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[Kk]oslis$") , group=1)
def ko(app : Client,msg : Message):
    txp = '**ای کصلیس کم بلیس تا کامروا شوی!**'
    app.send_message(
    msg.chat.id,
    txp,
    )

@Client.on_message(Filters.me & (Filters.group|Filters.private) & Filters.regex("^[game]$") , group=4)
def game(app : Client,msg : Message):
    for i in game:
        app.edit_message_text(msg.chat.id,msg.message_id,i)
        if r.get("autodel") == "on":
            time.sleep(float(r.get("autodeltime")))
            app.delete_messages(msg.chat.id,msg.message_id)
